package Stage1;

public class Main {

    public static void main(String[] args) {
        EquationSolver equationSolver = new EquationSolver();
        System.out.println(equationSolver.trapezoidMethod(1, 5));
        System.out.println(equationSolver.rectangleMethod(1,5));
        System.out.println(equationSolver.simpsonMethod(1, 5));
    }
}
