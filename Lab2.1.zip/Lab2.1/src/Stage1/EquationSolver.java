package Stage1;

public class EquationSolver {
    private final double h = 0.2;

    private double function(double x) {
        return Math.E/(Math.sqrt(1 + Math.pow(x, 2) + x));
    }

    public double trapezoidMethod(double A, double B) {
        double result = 0;
        double n = (B-A)/h;
        double x = A;

        result = (function(A) + function(B))/2;

        for (int i = 1; i < n - 1; i++) {
            x += h;
            result += function(x);
        }

        result=h*result;
        return result;
    }

    public double rectangleMethod(double A, double B) {
        double result = 0;
        double n = (B-A)/h;
        double x = A;

        for (int i = 0; i < n - 1; i++) {
            result += function(x);
            x += h;
        }

        result *= h;

        return  result;
    }

    public double simpsonMethod(double A, double B) {
        double result = 0;
        double n = (B-A)/h;
        double x = A;

        result = (function(A) + function(B))/2;

        double result1 = 0;

        for (int i = 1; i < n - 1; i++) {
            x += h;
            if (i % 2 != 0)
                result1 += function(x);
        }

        result += result1 * 2;

        double result2 = 0;
        x = A + h;

        for (int k = 2; k < n - 2; k++) {
            x += h;
            if (k % 2 == 0)
                result2 += function(x);
        }

        result += result2;

        result = result * h * 2 / 3;

        return result;
    }
}
